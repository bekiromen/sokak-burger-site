document.addEventListener("DOMContentLoaded", () => {
  console.log("Sokak Burger sitesi hazır!");
});
